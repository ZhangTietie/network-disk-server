#include <iostream>  
#include "md5.h"  
  
using namespace std;  
  
int main(int argc, char *argv[])  
{  
    cout << "md5 of 'grape': " << md5("aaa")<<endl;  
    return 0;  
}
