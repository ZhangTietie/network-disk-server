#/bin/bash
rm -rf build log && mkdir -p build && cd build && cmake ..&& make
